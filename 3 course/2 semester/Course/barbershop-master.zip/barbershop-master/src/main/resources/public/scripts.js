$(document).ready(function() {
    $('.sortable-table').DataTable({
      "searching": false
    });

} );
