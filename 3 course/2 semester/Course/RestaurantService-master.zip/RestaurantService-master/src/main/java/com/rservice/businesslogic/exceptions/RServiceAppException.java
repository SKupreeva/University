package com.rservice.businesslogic.exceptions;

public class RServiceAppException extends Exception {

    public RServiceAppException(String message) {
        super(message);
    }
}
