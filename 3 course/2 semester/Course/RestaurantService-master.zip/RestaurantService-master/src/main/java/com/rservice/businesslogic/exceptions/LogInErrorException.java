package com.rservice.businesslogic.exceptions;

public class LogInErrorException extends Exception {

    public LogInErrorException(String message) {
        super(message);
    }
}
